"""
ZeroEnv - Git-Safe Secrets
"""

__version__ = "0.1.0"
__author__ = "David"
__description__ = "Git-Safe Secrets for small teams and individuals."
